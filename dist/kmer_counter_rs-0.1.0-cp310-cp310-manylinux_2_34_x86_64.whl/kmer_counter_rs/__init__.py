from .kmer_counter_rs import *

__doc__ = kmer_counter_rs.__doc__
if hasattr(kmer_counter_rs, "__all__"):
    __all__ = kmer_counter_rs.__all__